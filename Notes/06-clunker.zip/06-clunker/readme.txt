This data and script was used to calculate the MPG distributions for the "Cash for Clunkers" interactive example in "What Can A Technologist Do About Climate Change?"

    http://worrydream.com/ClimateChange/
