#! /usr/bin/perl -w
#
# usage:  perl get-distribution.pl
#
# The MPG data should be in the mpg-data directory.
# Data came from https://www.fueleconomy.gov/feg/download.shtml

use strict;


my $startyear = 1984;
my $endyear = 2004;

#my $startyear = 2008;
#my $endyear = 2008;


# car sales by year, starting from 1984, in millions
# http://www.statista.com/statistics/199974/us-car-sales-since-1951/

my @weights = ( 10.3, 11.0, 11.4, 10.2, 10.5, 9.8, 9.3, 8.2, 8.2, 8.5, 9.0, 8.6, 8.5, 8.2, 8.1, 8.6, 8.8, 8.4, 8.0, 7.6, 7.5, 7.7, 7.8, 7.6, 6.8, 5.4, 5.6, 6.1, 7.2, 7.8, 7.9 );


my %distribution;

for my $year ($startyear .. $endyear) {
    my ($shortyear) = ($year =~ /..(..)/);

    my $filename = "mpg-data/$shortyear.txt";
    print "opening $filename\n";

    my $opened = open FILE, $filename;
    if (!$opened) { print "couldn't open $filename\n"; next; }

    for my $number (<FILE>) {
        chomp $number;
        $number =~ s/\s*//g;
        $distribution{ $number } += $weights[ $year - $startyear ];
    }
    close FILE;
}

print "[ ";
for my $mpg (0 .. 46) {
    my $value = int(0.5 + ($distribution{$mpg} || 0));
    print "$value, ";
}
print "]\n";
